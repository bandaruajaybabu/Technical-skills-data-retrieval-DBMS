package technicalskills;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


 public class insert_learnedby extends JFrame{

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		JPanel jp1,jp2,jp3;
		Connection con;
		int i;
		java.sql.Statement stmt;
		JLabel sid,tid,since; 
		JTextField s,t,si;
		TextArea ta;
		JButton in;
		
		public insert_learnedby()
		{
			try 
			{
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ajay","vasavi");
				stmt=con.createStatement();
			
			} 
			
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			sid=new JLabel("student id");
			s=new JTextField(10);
			tid=new JLabel("technical ID");
			t=new JTextField(10);
			since=new JLabel("date");
			si=new JTextField(10);
			ta=new TextArea(20,100);
			in=new JButton("submit");
			jp1=new JPanel(new GridLayout(5,1));
			jp2=new JPanel(new FlowLayout());
			jp3=new JPanel(new FlowLayout());
			jp1.add(sid);
			jp1.add(s);
			jp1.add(tid);
			jp1.add(t);
			jp1.add(since);
			jp1.add(si);
			jp2.add(in);
			jp3.add(ta);
			add(jp1);
		//	"insert into technicalskills values("+ t.getText() +",'"+sn.getText()+"','"+d.getText()+"','"+e.getText()+"',"+y.getText()+",'"+b.getText()+"')"
			add(jp2);
			add(jp3);
			setVisible(true);
			getContentPane().setBackground(Color.blue);
			setSize(2000,1000);
			setTitle("Enter following details:");
			setLayout(new GridLayout(5,2));
			pack();
			
		in.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					// TODO Auto-generated method stub
					try {
						
						i=stmt.executeUpdate("insert into learnedby values('"+s.getText()+"',"+t.getText()+",'"+si.getText()+"')");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					ta.append("\n Inserted "+i+"rows successfully");
				}
			});

}
		}
