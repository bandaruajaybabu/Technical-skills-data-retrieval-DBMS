package technicalskills;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
//import javax.xml.ws.AsyncHandler;

public class update_certified_in extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JPanel jp1,jp2,jp3;
	JLabel sid,cid,passedon; 
	JTextField s,c,p;
	Connection con;
	int i;
	java.sql.Statement stmt;
	
	TextArea ta;
	JButton in;
	List lis1,lis2;
	ResultSet rs;
	String sel1,sel2;
	
	public update_certified_in()
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ajay","vasavi");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt=con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		lis1=new List();
		lis2=new List();
		sid=new JLabel("student id");
		s=new JTextField(10);
		cid=new JLabel("course ID");
		c=new JTextField(10);
		passedon=new JLabel("date of qualification");
		p=new JTextField(10);
		ta=new TextArea(20,100);
		in=new JButton("submit");
		jp1=new JPanel(new GridLayout(3,2));
		jp2=new JPanel(new FlowLayout());
		jp3=new JPanel(new FlowLayout());
		jp1.add(sid);
		jp1.add(s);
		jp1.add(cid);
		jp1.add(c);
		jp1.add(passedon);
		jp1.add(p);
		jp2.add(in);
		jp3.add(ta);
		add(jp1);
		add(jp2);
		add(jp3);
		add(lis1);
		add(lis2);
		try {
			rs=stmt.executeQuery("select sid from certified_in ");
			while(rs.next()) {
				lis1.add(rs.getString(1));
				//lis2.add(rs.getString(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			rs=stmt.executeQuery("select cid from certified_in");
			while(rs.next()) {
				lis2.add(rs.getString(1));
				//lis2.add(rs.getString(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		lis1.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent arg0) {
				sel1=lis1.getSelectedItem();
				if(sel1!=null && sel2!=null){
					try {
						rs=stmt.executeQuery("select sid,cid,passedon from certified_in where sid='"+lis1.getSelectedItem()+"' and cid='"+lis2.getSelectedItem()+"'");
						if(rs.next()) {
							s.setText(rs.getString(1));
							c.setText(rs.getString(2));
							p.setText(rs.getString(3));
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
			}			

		});
		lis2.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent arg0) {
				sel2=lis2.getSelectedItem();
				if(sel1!=null && sel2!=null){
					try {
						rs=stmt.executeQuery("select sid,cid,passedon from certified_in where sid='"+lis1.getSelectedItem()+"' and cid='"+lis2.getSelectedItem()+"'");
						if(rs.next()) {
							s.setText(rs.getString(1));
							c.setText(rs.getString(2));
							p.setText(rs.getString(3));
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
			}
		});
in.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				try {
					 i=stmt.executeUpdate("update certified_in set passedon='"+p.getText()+"'where sid='"+s.getText()+"' and  cid="+c.getText()+"''");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				ta.append("\n Updated "+i+"rows successfully");
			}
		});
		setVisible(true);
		setSize(2000,1000);
		setTitle("Enter following details:");
		setLayout(new GridLayout(3,1));
		pack();
		
	}


}