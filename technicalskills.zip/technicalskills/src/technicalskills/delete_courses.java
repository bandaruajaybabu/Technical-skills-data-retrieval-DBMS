package technicalskills;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
//import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


 public class delete_courses extends JFrame{

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		JPanel jp1,jp2,jp3;
		Connection con;
		int i;
		java.sql.Statement stmt;
		JLabel cid,cname,duration; 
		JTextField c,cn,d;
		TextArea ta;
		JButton in;
		List lis;
		ResultSet rs;
		String sel;
		
		public delete_courses()
		{
			try 
			{
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ajay","vasavi");
				stmt=con.createStatement();
			
			} 
			
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			cid=new JLabel("course id");
			c=new JTextField(10);
			cname=new JLabel("name of course");
			cn=new JTextField(10);
			duration=new JLabel("duration of course");
			d=new JTextField(10);
			ta=new TextArea(20,100);
			in=new JButton("submit");
			jp1=new JPanel(new GridLayout(5,1));
			jp2=new JPanel(new FlowLayout());
			jp3=new JPanel(new FlowLayout());
			jp1.add(cid);
			jp1.add(c);
			jp1.add(cname);
			jp1.add(cn);
			jp1.add(duration);
			jp1.add(d);
			jp2.add(in);
			jp3.add(ta);	
			lis=new List();
			add(jp1);
		//	"insert into students values('"+ s.getText() +"','"+sn.getText()+"','"+d.getText()+"','"+e.getText()+"',"+y.getText()+",'"+b.getText()+"')"
			add(jp2);
			add(jp3);
			add(lis);
			try {
				rs=stmt.executeQuery("select cid from courses");
				while(rs.next()) {
					lis.add(rs.getString(1));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			lis.addItemListener(new ItemListener() {
				
				@Override
				public void itemStateChanged(ItemEvent arg0) {
					// TODO Auto-generated method stub
					try {
						sel=lis.getSelectedItem();
						rs=stmt.executeQuery("select cname,duration,cid from courses where cid='"+lis.getSelectedItem()+"'");
					if(rs.next()) {
						c.setText(rs.getString(1));
						cn.setText(rs.getString(2));
						d.setText(rs.getString(3));
						//c.setText(rs.getString(4));
					//	t.setText(rs.getString(5));
						//s.setText(rs.getString(6));
					}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}			

			});
in.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					// TODO Auto-generated method stub
					try {
						
						i=stmt.executeUpdate("delete from courses where cid='"+c.getText()+"'");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					ta.append("\n Deleted "+i+"rows successfully");
				}
			});


		
			setVisible(true);
			getContentPane().setBackground(Color.blue);
			setSize(2000,1000);
			setTitle("Enter following details:");
			setLayout(new FlowLayout());
			pack();
		
		}
	}
