package technicalskills;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
//import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


 public class update_technicalskills extends JFrame{

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		JPanel jp1,jp2,jp3;
		Connection con;
		int i;
		java.sql.Statement stmt;
		JLabel tid;
		JLabel programming_skills,web,graphical,computerskills; 
		JTextField t,p,w,g,c;
		TextArea ta;
		JButton in;
		List lis;
		ResultSet rs;
		String sel;
		void displaySQLErrors(Exception e2) {
			ta.append("\nSQLException:" + e2.getMessage() +"\n");
			ta.append("SQLState:    "+ ((SQLException) e2).getSQLState() + "\n");
			ta.append("VendorError:  " + ((SQLException) e2).getErrorCode() + "\n");
			
		}
		public update_technicalskills()
		{
			try 
			{
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ajay","vasavi");
				stmt=con.createStatement();
			
			} 
			
			catch (Exception e) {
				// TODO Auto-generated catch block
				displaySQLErrors(e);
				}
			tid=new JLabel("technicalskills id");
			t=new JTextField(10);
			programming_skills=new JLabel("name of programmingskills");
			p=new JTextField(10);
			web=new JLabel("name of web");
			w=new JTextField(10);
			graphical=new JLabel("name of graphical");
			g=new JTextField(10);
			computerskills=new JLabel("name of computer skills");
			c=new JTextField(10);
			//branch=new JLabel("student branch");
		//	b=new JTextField(10);
		//	email=new JLabel("student mailid");
			//e=new JTextField(10);
			ta=new TextArea(20,100);
			in=new JButton("submit");
			jp1=new JPanel(new GridLayout(5,1));
			jp2=new JPanel(new FlowLayout());
			jp3=new JPanel(new FlowLayout());
			jp1.add(tid);
			jp1.add(t);
			jp1.add(programming_skills);
			jp1.add(p);
			jp1.add(web);
			jp1.add(w);
			jp1.add(graphical);
			jp1.add(g);
			jp1.add(computerskills);
			jp1.add(c);
			//jp1.add(branch);
		//	jp1.add(b);
		//	jp1.add(email);
		//	jp1.add(e);
			jp2.add(in);
			jp3.add(ta);			
			lis=new List();
			add(jp1);
		//	"insert into students values('"+ s.getText() +"','"+sn.getText()+"','"+d.getText()+"','"+e.getText()+"',"+y.getText()+",'"+b.getText()+"')"
			add(jp2);
			add(jp3);
			add(lis);
			try {
				rs=stmt.executeQuery("select sid from students");
				while(rs.next()) {
					lis.add(rs.getString(1));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				displaySQLErrors(e);
			}
			lis.addItemListener(new ItemListener() {
				
				@Override
				public void itemStateChanged(ItemEvent arg0) {
					// TODO Auto-generated method stub
					try {
						sel=lis.getSelectedItem();
						rs=stmt.executeQuery("select programming_skills,web,graphical,computerskills,tid from technicalskills where tid='"+lis.getSelectedItem()+"'");
					if(rs.next()) {
						p.setText(rs.getString(1));
						w.setText(rs.getString(2));
						g.setText(rs.getString(3));
						c.setText(rs.getString(4));
						//b.setText(rs.getString(5));
						t.setText(rs.getString(6));
					}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						displaySQLErrors(e);
					}
				}			

			});
			in.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					// TODO Auto-generated method stub
					try {
						
						i=stmt.executeUpdate(" update technicalskills set programming_skills='"+p.getText()+"',web='"+w.getText()+"',graphical="+g.getText()+"'',computerskills='"+c.getText()+"' where tid="+t.getText()+"");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						displaySQLErrors(e);
					}
					ta.append("\n Updated "+i+"rows successfully");
				}
			});


		
			setVisible(true);
			getContentPane().setBackground(Color.blue);
			setSize(2000,1000);
			setTitle("Enter following details:");
			setLayout(new FlowLayout());
			pack();
		
		}
	}
