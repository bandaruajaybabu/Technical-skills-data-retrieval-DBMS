package technicalskills;


	import java.awt.Color;
	import java.awt.FlowLayout;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;

	import javax.swing.JFrame;
	import javax.swing.JMenu;
	import javax.swing.JMenuBar;
	import javax.swing.JMenuItem;

	public class First_frame extends JFrame {

		/**
		 * 
		 */
	//	private static final long serialVersionUID = 1L;
		JMenuBar mnubar;
		JMenu m1,m2,m3,m4,m5;
		JMenuItem in1,in2,in3,in4,in5,up1,up2,up3,up4,up5,dl1,dl2,dl3,dl4,dl5;
		public First_frame() {
			mnubar=new JMenuBar();
			m1=new JMenu("students");
			m2=new JMenu("technicalskills");
			m3=new JMenu("courses");
			m4=new JMenu("learnedby");
			m5=new JMenu("certifiedin");
			in2=new JMenuItem("Insert");
			up2=new JMenuItem("Update");
			dl2=new JMenuItem("Delete");
			getContentPane().setBackground(Color.blue);
			setVisible(true);
			setSize(500,400);
			setTitle("Technicalskills data retrival");
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setLayout(new FlowLayout());
			setJMenuBar(mnubar);
			mnubar.add(m1);
			mnubar.add(m2);
			mnubar.add(m3);
			mnubar.add(m4);
			mnubar.add(m5);
			m2.add(in2);
			m2.add(up2);
			m2.add(dl2);
			in2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new insert_technicalskills();
				dispose();
			}
		});
		up2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
			//	new update_technicalskills();
				
			}
		});
		dl2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			//	new delete_technicalskills();
				
			}
		});
		}
		public static void main(String a[]) {
			new First_frame();
		}
		
	}
