package technicalskills;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


 public class insert_students extends JFrame{

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		JPanel jp1,jp2,jp3;
		Connection con;
		int i;
		java.sql.Statement stmt;
		JLabel sid;
		JLabel email,dob,year,branch,sname; 
		JTextField s,e,d,y,b,sn;
		TextArea ta;
		JButton in;
		
		public insert_students()
		{
			try 
			{
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ajay","vasavi");
				stmt=con.createStatement();
			
			} 
			
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			sid=new JLabel("studentid");
			s=new JTextField(10);
			sname=new JLabel("name of student");
			sn=new JTextField(10);
			dob=new JLabel("date of birth");
			d=new JTextField(10);
			email=new JLabel("student mailid");
			e=new JTextField(10);
			year=new JLabel("student year");
			y=new JTextField(10);
			branch=new JLabel("student branch");
			b=new JTextField(10);
		//	email=new JLabel("student mailid");
			//e=new JTextField(10);
			ta=new TextArea(20,100);
			in=new JButton("submit");
			jp1=new JPanel(new GridLayout(5,1));
			jp2=new JPanel(new FlowLayout());
			jp3=new JPanel(new FlowLayout());
			jp1.add(sid);
			jp1.add(s);
			jp1.add(sname);
			jp1.add(sn);
			jp1.add(dob);
			jp1.add(d);
			jp1.add(email);
			jp1.add(e);
			jp1.add(year);
			jp1.add(y);
			jp1.add(branch);
			jp1.add(b);
		//	jp1.add(email);
		//	jp1.add(e);
			jp2.add(in);
			jp3.add(ta);
			add(jp1);
		//	"insert into students values('"+ s.getText() +"','"+sn.getText()+"','"+d.getText()+"','"+e.getText()+"',"+y.getText()+",'"+b.getText()+"')"
			add(jp2);
			add(jp3);
			setVisible(true);
			getContentPane().setBackground(Color.pink);
			setSize(2000,1000);
			setTitle("Enter following details:");
			setLayout(new GridLayout(5,2));
			pack();
			
		in.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					// TODO Auto-generated method stub
					try {
						
						i=stmt.executeUpdate("insert into students values('"+s.getText()+"','"+sn.getText()+"','"+d.getText()+"','"+e.getText()+"',"+y.getText()+",'"+b.getText()+"')");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					ta.append("\n Inserted "+i+"rows successfully");
				}
			});

}
		}