package technicalskills;


	import java.awt.Color;
	import java.awt.FlowLayout;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;

	import javax.swing.JFrame;
	import javax.swing.JMenu;
	import javax.swing.JMenuBar;
	import javax.swing.JMenuItem;

	public class firstframe extends JFrame {

		/**
		 * 
		 */
	//	private static final long serialVersionUID = 1L;
		JMenuBar mnubar;
		JMenu m1,m2,m3,m4,m5;
		JMenuItem in1,in2,in3,in4,in5,up1,up2,up3,up4,up5,dl1,dl2,dl3,dl4,dl5;
		public firstframe() {
			mnubar=new JMenuBar();
			m1=new JMenu("students");
			m2=new JMenu("technicalskills");
			m3=new JMenu("courses");
			m4=new JMenu("learnedby");
			m5=new JMenu("certifiedin");
			in1=new JMenuItem("Insert");
			up1=new JMenuItem("Update");
			dl1=new JMenuItem("Delete");
			in2=new JMenuItem("Insert");
			up2=new JMenuItem("Update");
			dl2=new JMenuItem("Delete");
			in3=new JMenuItem("Insert");
			up3=new JMenuItem("Update");
			dl3=new JMenuItem("Delete");
			in4=new JMenuItem("Insert");
			up4=new JMenuItem("Update");
			dl4=new JMenuItem("Delete");
			in5=new JMenuItem("Insert");
			up5=new JMenuItem("Update");
			dl5=new JMenuItem("Delete");
			getContentPane().setBackground(Color.blue);
			setVisible(true);
			setSize(500,400);
			setTitle("Technicalskills data retrival");
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setLayout(new FlowLayout());
			setJMenuBar(mnubar);
			mnubar.add(m1);
			mnubar.add(m2);
			mnubar.add(m3);
			mnubar.add(m4);
			mnubar.add(m5);
			m1.add(in1);
			m1.add(up1);
			m1.add(dl1);
			m2.add(in2);
			m2.add(up2);
			m2.add(dl2);
			m3.add(in3);
			m3.add(up3);
			m3.add(dl3);
			m4.add(in4);
			m4.add(up4);
			m4.add(dl4);
			m5.add(in5);
			m5.add(up5);
			m5.add(dl5);
			in1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new insert_students();
				dispose();
			}
		});
		up1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new update_students();
				
			}
		});
		dl1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new delete_students();
				
			}
		});
in2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new insert_technicalskills();
				dispose();
			}
		});
		up2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new update_technicalskills();
				
			}
		});
		dl2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new delete_technicalskills();
				
			}
		});
in3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new insert_courses();
				dispose();
			}
		});
		up3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new update_courses();
				
			}
		});
		dl3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new delete_courses();
				
			}
		});
in4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new insert_learnedby();
				dispose();
			}
		});
		up4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new update_learnedby();
				
			}
		});
		dl4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new delete_learnedby();
				
			}
		});
in5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new insert_certified_in();
				dispose();
			}
		});
		up5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new update_certified_in();
				
			}
		});
		dl5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new delete_certified_in();
				
			}
		});
		}
		public static void main(String a[]) {
			new firstframe();
		}
		
	}