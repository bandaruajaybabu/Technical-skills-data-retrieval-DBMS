	package technicalskills;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
//import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


 public class delete_students extends JFrame{

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		JPanel jp1,jp2,jp3;
		Connection con;
		int i;
		java.sql.Statement stmt;
		JLabel sid;
		JLabel email,dob,year,branch,sname; 
		JTextField s,e,d,y,b,sn;
		TextArea ta;
		JButton in;
		List lis;
		ResultSet rs;
		String sel;
		
		public delete_students()
		{
			try 
			{
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ajay","vasavi");
				stmt=con.createStatement();
			
			} 
			
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			sid=new JLabel("studentid");
			s=new JTextField(10);
			sname=new JLabel("name of student");
			sn=new JTextField(10);
			dob=new JLabel("date of birth");
			d=new JTextField(10);
			email=new JLabel("student mailid");
			e=new JTextField(10);
			year=new JLabel("student year");
			y=new JTextField(10);
			branch=new JLabel("student branch");
			b=new JTextField(10);
		//	email=new JLabel("student mailid");
			//e=new JTextField(10);
			ta=new TextArea(20,100);
			in=new JButton("submit");
			jp1=new JPanel(new FlowLayout());
			jp2=new JPanel(new FlowLayout());
			jp3=new JPanel(new FlowLayout());
			jp1.add(sid);
			jp1.add(s);
			jp1.add(sname);
			jp1.add(sn);
			jp1.add(dob);
			jp1.add(d);
			jp1.add(email);
			jp1.add(e);
			jp1.add(year);
			jp1.add(y);
			jp1.add(branch);
			jp1.add(b);
		//	jp1.add(email);
		//	jp1.add(e);
			jp2.add(in);
			jp3.add(ta);
			lis=new List();
			add(jp1);
		//	"insert into students values('"+ s.getText() +"','"+sn.getText()+"','"+d.getText()+"','"+e.getText()+"',"+y.getText()+",'"+b.getText()+"')"
			add(jp2);
			add(jp3);
			add(lis);
			try {
				rs=stmt.executeQuery("select sid from students");
				while(rs.next()) {
					lis.add(rs.getString(1));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			lis.addItemListener(new ItemListener() {
				
				@Override
				public void itemStateChanged(ItemEvent arg0) {
					// TODO Auto-generated method stub
					try {
						sel=lis.getSelectedItem();
						rs=stmt.executeQuery("select sname,email,dob,year,branch,sid from students where sid='"+lis.getSelectedItem()+"'");
					if(rs.next()) {
						sn.setText(rs.getString(1));
						e.setText(rs.getString(2));
						d.setText(rs.getString(3));
						y.setText(rs.getString(4));
						b.setText(rs.getString(5));
						s.setText(rs.getString(6));
					}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}			

			});
in.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					// TODO Auto-generated method stub
					try {
						
						i=stmt.executeUpdate("delete from students where sid='"+s.getText()+"'");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					ta.append("\n Deleted "+i+"rows successfully");
				}
			});


		
			setVisible(true);
			getContentPane().setBackground(Color.blue);
			setSize(2000,1000);
			setTitle("Enter following details:");
			setLayout(new FlowLayout());
			pack();
		
		}
	}